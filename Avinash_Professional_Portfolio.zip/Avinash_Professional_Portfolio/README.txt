AVINASH REEDY — PROFESSIONAL PORTFOLIO

This is a responsive static portfolio website based on the supplied Avinash_workday.pdf résumé.

HOW TO VIEW
1. Extract the ZIP file.
2. Open index.html in a modern browser.

HOW TO PUBLISH
Upload the contents of this folder to any static website host (for example GitHub Pages, Netlify, or your own hosting).
Keep the files folder beside index.html so the portrait and résumé download work.

CONTENT NOTE
The portfolio uses the career history, skills, employers, education and contact details supplied in the résumé.
No project names, metrics, certifications or social profile URLs have been invented.
