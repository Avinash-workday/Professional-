const toggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".navigation");
if (toggle && nav) {
  toggle.addEventListener("click", () => {
    const open = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!open));
    nav.classList.toggle("open", !open);
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  }));
}
const year = document.querySelector("#year");
if (year) year.textContent = new Date().getFullYear();
const toast = document.querySelector(".toast");
const copy = document.querySelector(".copy-email");
if (copy && toast) copy.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText("AvinashYeruva0@gmail.com");
    toast.textContent = "Email address copied.";
  } catch {
    toast.textContent = "Copy unavailable — use the email link above.";
  }
  toast.classList.add("visible");
  setTimeout(() => toast.classList.remove("visible"), 2400);
});
